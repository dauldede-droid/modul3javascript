console.log("Eksekusi my_code_2.js");
document.getElementById("myH1").innerHTML += " & my_code_2.js";
