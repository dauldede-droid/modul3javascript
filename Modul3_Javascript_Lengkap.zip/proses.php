<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Proses Form</title>
</head>
<body>
  <h1>Data Berhasil Dikirim!</h1>
  <p>Username: <?php echo isset($_GET['username']) ? htmlspecialchars($_GET['username']) : '-'; ?></p>
  <a href="form.html">Kembali ke Form</a>
</body>
</html>
