console.log("Eksekusi my_code_1.js");
document.getElementById("myH1").innerHTML = "Hello World dari my_code_1.js";
